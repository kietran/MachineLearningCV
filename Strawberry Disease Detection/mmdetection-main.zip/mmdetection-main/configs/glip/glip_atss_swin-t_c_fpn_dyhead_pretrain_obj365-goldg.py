_base_ = './glip_atss_swin-t_b_fpn_dyhead_pretrain_obj365.py'
